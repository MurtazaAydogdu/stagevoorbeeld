version 0.0.2
--------------
+ Added the dobi files and migrations for the database

version 0.0.1
--------------
+ initialised project structure